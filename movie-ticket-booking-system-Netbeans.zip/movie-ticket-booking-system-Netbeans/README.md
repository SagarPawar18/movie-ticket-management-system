# movie-ticket-booking-system-Netbeans

In this project movie ticket is booked  using  movie Ticket booking system. We enter into Web page by logging with User Name and Password. 
Then we select the Movie and later in which Theatre movie is running. Later choose Show Timings and enter no of tickets you want .
Finally it displays the details of the procedure and print the form to show at respective ticket counter to get ticket. 


